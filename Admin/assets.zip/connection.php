<?php

                    //Connection Stablishing...
                    $con = mysqli_connect("localhost", "admin", "admin123", "nft") or die("Query Failed!!!");
                    
?>