<?php

                    //Connection Stablishing...
                    $con = mysqli_connect("localhost", "root", "", "nft") or die("Query Failed!!!");
                    
?>